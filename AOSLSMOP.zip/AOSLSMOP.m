classdef AOSLSMOP< ALGORITHM
% <multi/many> <real> <large/none> <constrained/none>
% Large-scale multi-objective competitive swarm optimization algorithm



    methods
        function main(Algorithm,Problem)
%             RefNo = floor(Problem.FE * 0.1);
            %% Generate random population  产生随机种群
            [V,Problem.N] = UniformPoint(Problem.N,Problem.M);
            Population    = Problem.Initialization();
%             Population    = EnvironmentalSelection(Population,V,(Problem.FE/Problem.maxFE)^2);
%             Offspring     = Problem.Initialization();
%             Arc           = Population;
%             [Population,FrontNo] = PreSelection([Population,Offspring],V,(Problem.FE/Problem.maxFE)^2,RefNo);
%                 Offspring = DirectionReproduction(Problem,Population,FrontNo,RefNo);
      NV     = size(V,1);
%     [Front,MaxFront] = NDSort(Population.objs,min([NV,length(Population)]));%非支配排序
%     First = find(Front ==1);
%     Second = find(Front >1);
%     D=length(Population);%D=53
%     
%       FirstPoint =  randperm(length(First),1);
% 
%     r1     = repmat(Population(FirstPoint).decs,length(Second),1);
%  
%     rand1=rand();
% 
%       PopulationvFirst=(1-rand1).*Population(Second).decs+rand1.*r1;
% 
%       Offspring1 = SOLUTION(PopulationvFirst);
% 
%       Population=[Population,Offspring1];

            %% Optimization
            while Algorithm.NotTerminated(Population)
%                 Fitness = calFitness(Population.objs);
%                 if length(Population) >= 2
%                     Rank = randperm(length(Population),floor(length(Population)/2)*2);
%                 else
%                     Rank = [1,1];
%                 end
%                 Loser  = Rank(1:end/2);
%                 Winner = Rank(end/2+1:end);
%                 Change = Fitness(Loser) >= Fitness(Winner);
%                 Temp   = Winner(Change);
%                 Winner(Change) = Loser(Change);
%                 Loser(Change)  = Temp;
%                 Offspring      = Operator(Population(Loser),Population(Winner));

    [Front,MaxFront] = NDSort(Population.objs,min([NV,length(Population)]));%非支配排序
    First = find(Front ==1);
    Second = find(Front >1);
    
    if(length(Second)<10)
        if(length(First)<(10-length(Second)))
            third=[Second,First];
            Second=third;
        else
        third=[Second,randperm(length(First),(10-length(Second)))];
        Second=third;
        end
    end
    
%     D=length(Population);%D=53
    
      selected =  randperm(length(First),1);


    r1     = repmat(Population(selected).decs,length(Second),1);

    rand1=rand();
    rand2=rand();

    fprintf("First=%d…\n", length(First));

%       PopulationFirst=(1-rand1).*Population(Second).decs+rand1.*r1;
%       PopulationFirst=1.5*rand1.*Population(Second).decs+1.5*rand2.*r1;
PopulationFirst=1.49445*rand1.*Population(Second).decs+1.49445*rand2.*r1;
      OffspringPopulation=PopulationFirst;
      
      
      [~,D]=size(Population.decs);
 %% Polynomial mutation 多项式变异
	OffDec = OffspringPopulation;
    N      = size(OffDec,1);
    Lower  = repmat(Problem.lower,N,1);
    Upper  = repmat(Problem.upper,N,1);
    disM   = 20;
    Site   = rand(N,D) < 1/Problem.D;
    mu     = rand(N,D);
    temp   = Site & mu<=0.5;
    OffDec = max(min(OffDec,Upper),Lower);
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                   (1-(OffDec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp  = Site & mu>0.5; 
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                   (1-(Upper(temp)-OffDec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
	Offspring = SOLUTION(OffDec);
        
     
%       
%       Offspring = SOLUTION(OffspringPopulation);



% Population = subNSGAII([Population,Offspring],Problem.N);
% 
% Population = subRVEA([Population,Offspring],V,(Problem.FE/Problem.maxFE)^2);
                Population     = EnvironmentalSelection2([Population,Offspring],V,(Problem.FE/Problem.maxFE)^2);
            end
        end
    end
end

function Fitness = calFitness(PopObj)
% Calculate the fitness by shift-based density

    N      = size(PopObj,1);
    fmax   = max(PopObj,[],1);
    fmin   = min(PopObj,[],1);
    PopObj = (PopObj-repmat(fmin,N,1))./repmat(fmax-fmin,N,1);
    Dis    = inf(N);
    for i = 1 : N
        SPopObj = max(PopObj,repmat(PopObj(i,:),N,1));
        for j = [1:i-1,i+1:N]
            Dis(i,j) = norm(PopObj(i,:)-SPopObj(j,:));
        end
    end
    Fitness = min(Dis,[],2);
end